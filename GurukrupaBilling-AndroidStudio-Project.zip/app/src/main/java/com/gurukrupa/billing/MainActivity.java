package com.gurukrupa.billing;

import android.app.*;
import android.os.Bundle;
import android.graphics.Typeface;
import android.content.*;
import android.print.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;
import java.text.*;

public class MainActivity extends Activity {
  LinearLayout root, itemsBox; TextView totalView; ArrayList<Row> rows=new ArrayList<>();
  double total=0; int next=1;
  class Row { EditText qty, rate; TextView name, sub; LinearLayout box; }
  int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
  TextView text(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(dp(5),dp(5),dp(5),dp(5)); return t; }
  EditText edit(String val){ EditText e=new EditText(this); e.setSingleLine(true); e.setText(val); e.setTextSize(16); e.setSelectAllOnFocus(true); e.setInputType(8194); e.setPadding(dp(8),dp(2),dp(8),dp(2)); return e; }
  Button button(String s){ Button b=new Button(this); b.setText(s); return b; }
  @Override public void onCreate(Bundle b){super.onCreate(b);
    ScrollView sc=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(12),dp(8),dp(12),dp(12)); sc.addView(root); setContentView(sc);
    TextView head=text("श्री गुरुकृपा किराणा स्टोअर्स\nनवीन बिल",22); head.setTypeface(null,Typeface.BOLD); head.setGravity(17); root.addView(head);
    TextView cols=text("वस्तू                         QTY        RATE       SUBTOTAL",12); root.addView(cols);
    itemsBox=new LinearLayout(this); itemsBox.setOrientation(1); root.addView(itemsBox);
    totalView=text("एकूण: ₹0.00",22); totalView.setTypeface(null,Typeface.BOLD); totalView.setGravity(17); root.addView(totalView);
    LinearLayout actions=new LinearLayout(this); actions.setOrientation(1); root.addView(actions);
    Button add=button("+ Add Item"); add.setOnClickListener(v->addRow()); actions.addView(add);
    Button calc=button("×  Calculate / Update"); calc.setOnClickListener(v->updateTotal()); actions.addView(calc);
    Button save=button("Save Bill"); save.setOnClickListener(v->{getPreferences(0).edit().putString("last_bill",billText()).apply(); new AlertDialog.Builder(this).setMessage("बिल सेव्ह केले").setPositiveButton("OK",null).show();}); actions.addView(save);
    Button history=button("Bill History"); history.setOnClickListener(v->{String s=getPreferences(0).getString("last_bill","अजून बिल सेव्ह केलेले नाही."); new AlertDialog.Builder(this).setTitle("शेवटचे सेव्ह केलेले बिल").setMessage(s).setPositiveButton("OK",null).show();}); actions.addView(history);
    Button print=button("Print Bill"); print.setOnClickListener(v->printBill()); actions.addView(print);
    addRow(); addRow(); addRow();
  }
  void addRow(){
    Row r=new Row(); r.box=new LinearLayout(this); r.box.setOrientation(1); r.box.setPadding(dp(6),dp(6),dp(6),dp(6)); r.box.setBackgroundColor(0xFFF1F5F9);
    r.name=text("Item "+next++,16); r.name.setTypeface(null,Typeface.BOLD); r.box.addView(r.name);
    LinearLayout fields=new LinearLayout(this); fields.setOrientation(0);
    r.qty=edit("1"); r.rate=edit("0"); r.sub=text("₹0.00",16);
    fields.addView(r.qty,new LinearLayout.LayoutParams(0,dp(48),1)); fields.addView(text("×",18));
    fields.addView(r.rate,new LinearLayout.LayoutParams(0,dp(48),1)); fields.addView(r.sub,new LinearLayout.LayoutParams(0,dp(48),1));
    r.box.addView(fields);
    LinearLayout btns=new LinearLayout(this); btns.setOrientation(0);
    Button minus=button("−"); Button plus=button("+"); Button del=button("Delete");
    minus.setOnClickListener(v->{r.qty.setText(""+Math.max(0,number(r.qty)-1));updateTotal();});
    plus.setOnClickListener(v->{r.qty.setText(""+(number(r.qty)+1));updateTotal();});
    del.setOnClickListener(v->{itemsBox.removeView(r.box);rows.remove(r);updateTotal();});
    btns.addView(minus,new LinearLayout.LayoutParams(0,dp(44),1)); btns.addView(plus,new LinearLayout.LayoutParams(0,dp(44),1)); btns.addView(del,new LinearLayout.LayoutParams(0,dp(44),1)); r.box.addView(btns);
    itemsBox.addView(r.box); rows.add(r);
    android.text.TextWatcher w=new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){updateTotal();} public void afterTextChanged(android.text.Editable e){}};
    r.qty.addTextChangedListener(w); r.rate.addTextChangedListener(w); updateTotal();
  }
  double number(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception ex){return 0;}}
  void updateTotal(){total=0; for(Row r:rows){double sub=number(r.qty)*number(r.rate); total+=sub; r.sub.setText(String.format(Locale.US,"₹%.2f",sub));} if(totalView!=null) totalView.setText(String.format(Locale.US,"एकूण: ₹%.2f",total));}
  String billText(){StringBuilder s=new StringBuilder("श्री गुरुकृपा किराणा स्टोअर्स\n"); for(Row r:rows)s.append(r.name.getText()).append(" | Qty ").append(r.qty.getText()).append(" | Rate ₹").append(r.rate.getText()).append(" | ₹").append(String.format(Locale.US,"%.2f",number(r.qty)*number(r.rate))).append("\n"); s.append("एकूण: ₹").append(String.format(Locale.US,"%.2f",total)); return s.toString();}
  void printBill(){String content=billText(); PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE); pm.print("Gurukrupa Bill",new PrintDocumentAdapter(){
    public void onLayout(PrintAttributes oldA,PrintAttributes newA,CancellationSignal c,LayoutResultCallback cb,Bundle extras){if(c.isCanceled()){cb.onLayoutCancelled();return;} PrintDocumentInfo info=new PrintDocumentInfo.Builder("gurukrupa-bill.txt").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(); cb.onLayoutFinished(info,true);}
    public void onWrite(PageRange[] pages,android.os.ParcelFileDescriptor fd,CancellationSignal c,WriteResultCallback cb){try(java.io.FileOutputStream out=new java.io.FileOutputStream(fd.getFileDescriptor())){out.write(content.getBytes("UTF-8"));cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){cb.onWriteFailed(e.toString());}}
  },null);}
}
